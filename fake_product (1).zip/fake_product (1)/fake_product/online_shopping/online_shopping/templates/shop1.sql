/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50130
Source Host           : localhost:3306
Source Database       : shop

Target Server Type    : MYSQL
Target Server Version : 50130
File Encoding         : 65001

Date: 2019-03-02 13:20:02
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `brand`
-- ----------------------------
DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `bcode` varchar(20) NOT NULL,
  `bname` varchar(20) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`bcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of brand
-- ----------------------------

-- ----------------------------
-- Table structure for `cart`
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cartid` int(20) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(20) NOT NULL,
  `cid` int(20) NOT NULL,
  `cdate` varchar(25) NOT NULL,
  PRIMARY KEY (`cartid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cart
-- ----------------------------

-- ----------------------------
-- Table structure for `cat`
-- ----------------------------
DROP TABLE IF EXISTS `cat`;
CREATE TABLE `cat` (
  `catcode` varchar(20) NOT NULL,
  `catname` varchar(20) NOT NULL,
  PRIMARY KEY (`catcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cat
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) NOT NULL,
  `addr` varchar(20) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gen` varchar(15) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer
-- ----------------------------

-- ----------------------------
-- Table structure for `delboy`
-- ----------------------------
DROP TABLE IF EXISTS `delboy`;
CREATE TABLE `delboy` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `dname` varchar(20) NOT NULL,
  `addr` varchar(20) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `dlno` varchar(20) NOT NULL,
  `gen` varchar(15) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of delboy
-- ----------------------------

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `uid` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `upass` varchar(20) NOT NULL,
  `utype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('0', 'admin', 'admin', 'admin');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `oid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` varchar(20) NOT NULL,
  `vid` varchar(20) NOT NULL,
  `pcode` varchar(20) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `amt` varchar(20) NOT NULL,
  `ptype` varchar(30) NOT NULL,
  `bank` varchar(30) DEFAULT NULL,
  `odate` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `did` int(11) DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(20) NOT NULL,
  `pname` varchar(25) NOT NULL,
  `descp` varchar(500) NOT NULL,
  `catcode` varchar(25) NOT NULL,
  `subcatcode` varchar(25) NOT NULL,
  `brand` varchar(25) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `amt` varchar(20) NOT NULL,
  `vid` varchar(20) NOT NULL,
  `img` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of product
-- ----------------------------

-- ----------------------------
-- Table structure for `shop`
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) NOT NULL,
  `addr` varchar(20) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `lno` varchar(50) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shop
-- ----------------------------
