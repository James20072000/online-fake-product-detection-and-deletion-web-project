"""online_shopping URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import  include, url,patterns
from shopping.views import *
from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
admin.autodiscover()
urlpatterns = [
	url(r'^$',TemplateView.as_view(template_name ='index.html')),
	url(r'^home/$',TemplateView.as_view(template_name ='index.html')),
	url(r'^searchlogin/$',searchlogin,name='searchlogin'),
	url(r'^register/$',TemplateView.as_view(template_name ='register.html')),
	url(r'^bhome/$',TemplateView.as_view(template_name ='buyerhome.html')),
	url(r'^registration/$',TemplateView.as_view(template_name ='registration.html')),
	url(r'^shopregistration/$',TemplateView.as_view(template_name ='shopregistration.html')),
	url(r'^dregistration/$',TemplateView.as_view(template_name ='dregistration.html')),
	url(r'^login/$',login,name='login'),
	url(r'^sellerhome/$',sellerhome,name='sellerhome'),
	url(r'^vsellerproduct/$',vsellerproduct,name='vsellerproduct'),
	url(r'^logout/$',logout,name='logout'),
	url(r'^brand/$',brand,name='brand'),
	url(r'^addbrand/$',addbrand,name='addbrand'),
	url(r'^deletebrand/$',deletebrand,name='deletebrand'),
	url(r'^cat/$',cat,name='cat'),
	url(r'^addcat/$',addcat,name='addcat'),
	url(r'^deletecat/$',deletecat,name='deletecat'),
	url(r'^vcat/$',vcat,name='vcat'),
	url(r'^sell/$',sell,name='sell'),
	url(r'^productadd/$',productadd,name='productadd'),
	url(r'^stock/$',stock,name='stock'),
	url(r'^updateproduct/$',updateproduct,name='updateproduct'),
	url(r'^editstock/$',editstock,name='editstock'),
	url(r'^deleteproduct/$',deleteproduct,name='deleteproduct'),
	url(r'^regaction/$',regaction,name='regaction'),
	url(r'^shopregaction/$',shopregaction,name='shopregaction'),
	url(r'^dregaction/$',dregaction,name='dregaction'),
	url(r'^buyerhome/$',buyerhome,name='buyerhome'),
	url(r'^buyerhome1/$',buyerhome1,name='buyerhome1'),
	url(r'^viewproduct/$',viewproduct,name='viewproduct'),
	url(r'^addcart/$',addcart,name='addcart'),
	url(r'^rvaction/$',rvaction,name='rvaction'),
	url(r'^buyaction/$',buyaction,name='buyaction'),
	url(r'^buyaction1/$',buyaction1,name='buyaction1'),
	url(r'^pay/$',pay,name='pay'),
	url(r'^payaction/$',payaction,name='payaction'),
	url(r'^nbaction/$',nbaction,name='nbaction'),
	url(r'^nb/$',nb,name='nb'),
	url(r'^viewcart/$',viewcart,name='viewcart'),
	url(r'^track/$',track,name='track'),
	url(r'^cancelorder/$',cancelorder,name='cancelorder'),
	url(r'^returnorder/$',returnorder,name='returnorder'),
	url(r'^deleteseller/$',deleteseller,name='deleteseller'),
	url(r'^vdelboy/$',vdelboy,name='vdelboy'),
	url(r'^deletedelboy/$',deletedelboy,name='deletedelboy'),
	url(r'^vbuyer/$',vbuyer,name='vbuyer'),
	url(r'^orders/$',orders,name='orders'),
	url(r'^collect/$',collect,name='collect'),
	url(r'^deliverd/$',deliverd,name='deliverd'),
	url(r'^ReturnCollected/$',ReturnCollected,name='ReturnCollected'),
	url(r'^admin1/$',admin1,name='admin1'),
	url(r'^user/$',user,name='user'),
	url(r'^seller/$',seller,name='seller'),
	url(r'^deletecart/$',deletecart,name='deletecart'),
	url(r'^recievedreplaced/$',recievedreplaced,name='recievedreplaced'),
	url(r'^deleteac_shop/$',deleteac_shop,name='deleteac_shop'),
	url(r'^deleteac_dboy/$',deleteac_dboy,name='deleteac_dboy'),
	url(r'^deleteac_user/$',deleteac_user,name='deleteac_user'),
	url(r'^productcust/$',productcust,name='productcust'),
	url(r'^dproduct/$',dproduct,name='dproduct'),
	url(r'^like/$',like,name='like'),
	url(r'^dlike/$',dlike,name='dlike'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += staticfiles_urlpatterns()
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()
