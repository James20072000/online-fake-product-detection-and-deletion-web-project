from django.shortcuts import render,redirect, render_to_response,HttpResponseRedirect
from django.db import connection
from django.http import HttpResponse
from django.template import Context
from django.template.loader import get_template
from django.template import Template, Context
from django.db import models
from django.contrib import messages
from django.contrib import messages
from shopping.forms import productform
from shopping.models import pmodel
from django.core.mail import send_mail
from django.core.mail import EmailMessage
from django.core.mail import send_mail
from django.http import HttpResponse
from django.http import JsonResponse
from django.core.files.storage import FileSystemStorage
from base64 import b64encode
from datetime import date
now= date.today()
utype={'u':'none'}
y={'uid':'none'}
#----------------------------------------------	LOGIN--------------------------------------------------------------------------------------------------------------------
def  login(request):
	return  render(request ,'login.html')
def  admin1(request):
		  return  render(request ,'adminhome.html')
def  user(request):
		 return render(request ,'buyerhome.html')
def  sellerhome(request):
	cursor = connection.cursor()
	cursor.execute(("select * from orders inner join shop on  orders.vid=shop.sid inner join customer on customer.cid=orders.cid  where orders.vid='%d'") %(request.session['uid']) )
	result = cursor.fetchall()
	list=[]
	for row in result:
		qty=int(row[4])
		amt=int(row[5])
		ta=(qty*amt);
		w = {'oid' : row[0],'cid': row[1],'vid':row[2],'pcode':row[3],'qty': row[4],'amt' : row[5],'ptype': row[6],'bank':row[7],'odate':row[8],'status': row[9],'did': row[10],'sid': row[11],'sname':row[12],'addr':row[13],'ph': row[14],'email': row[15],'lno':row[16],'cid': row[17],'cname':row[18],'caddr':row[19],'cph': row[20],'cemail': row[21],'gen':row[22],'ta':ta}
		list.append(w)
	#return HttpResponse(result)
	return render(request ,'sellerhome.html',{'list':list})
def searchlogin(request):
	cursor=connection.cursor()
	p=request.GET['t1']
	q=request.GET['t2']
	sql2="select * from login where uname='%s' and upass='%s' " %(p,q)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		sql3 = "select * from login  where uname='%s' and upass='%s'" % (p, q)
		cursor.execute(sql3)
		result1 = cursor.fetchall()
		for row1 in result1:
			d = row1[0]
			utype['u']=row1[3]
		y['uid']=d
		request.session['username'] = p
		request.session['uid'] = d
		request.session['utype'] =utype['u']
		if(utype['u']=='admin'):
			html="<script>alert(' logged in successfully ');window.location='/admin1/';</script>"
			#return render(request ,'adminhome.html') 
		elif(utype['u']=='shop'):
			html="<script>alert('logged in successfully ');window.location='/sellerhome/';</script>"
			#return render(request ,'sellerhome.html')logged in successfully 
		elif(utype['u']=='cust' ):
			html="<script>alert('logged in successfully  ');window.location='/buyerhome/';</script>"
			#buyerhome1()
			#return render(request ,'buyerhome.html')
		elif(utype['u']=='dboy' ):
			html="<script>window.location='/dboyhome/';</script>"
		return HttpResponse(html)
			#return render(request ,'dboyhome.html')
	else:
		html="<script>alert('invalid password and username ');window.location='/login/';</script>"
		messages.success(request, 'Changes successfully saved.')
		return HttpResponse(html)
def logout(request):
	try:
		del request.session['uid']
		del request.session['utype']
	except:
		pass
	return HttpResponse("<script>alert('you are loged out');window.location='/login/';</script>")
# ----------------------------------------------user registration--------------------------------------------------------------------------------------------------------------------	
def seller(request):
	cursor = connection.cursor()
	cursor.execute("select * from shop")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'sid' : row[0],'sname': row[1],'addr':row[2],'ph':row[3],'email': row[4],'lno': row[5]}
		list.append(w)
	return  render(request ,'seller.html',{'list':list})
def vsellerproduct(request):
	cursor = connection.cursor()
	cursor.execute(("select * from product inner join  shop  on shop.sid=product.vid where product.vid='%s'") %(request.GET['id']))
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'vid':row[8],'img': row[9],'cid': row[10],'sname': row[11],'addr':row[12],'ph':row[13],'email': row[14],'lno': row[15]}
		list.append(w)
	return  render(request ,'selpro.html',{'list':list})
def deleteseller(request):
	cursor=connection.cursor()
	sid=request.GET['id']
	sql="delete from  shop where  sid='%s'" %(sid)
	cursor.execute(sql)
	sql2="delete from  login where  uid='%s' and utype='shop'" %(sid)
	cursor.execute(sql2)
	sql3="delete from  product where  vid='%s'" %(sid)
	cursor.execute(sql3)
	html="<script>alert('successfully deleted!');window.location='/vsellerproduct/';</script>"
	return HttpResponse(html)
def vdelboy(request):
	cursor = connection.cursor()
	cursor.execute("select * from delboy")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'did' : row[0],'dname': row[1],'addr':row[2],'ph':row[3],'email': row[4],'dlno' : row[5],'gen': row[6]}
		list.append(w)
	return  render(request ,'dboy.html',{'list':list})
def deletedelboy(request):
	cursor=connection.cursor()
	sid=request.GET['id']
	sql="delete from  delboy where  did='%s'" %(sid)
	cursor.execute(sql)
	sql2="delete from  login where  uid='%s' and utype='dboy'" %(sid)
	cursor.execute(sql2)
	html="<script>alert('successfully deleted!');window.location='/vdelboy/';</script>"
	return HttpResponse(html)
def vbuyer(request):
	cursor = connection.cursor()
	cursor.execute("select * from customer")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'cid' : row[0],'cname': row[1],'addr':row[2],'ph':row[3],'email': row[4],'gen' : row[5]}
		list.append(w)
	return  render(request ,'buyer.html',{'list':list})
def brand(request):
	cursor = connection.cursor()
	cursor.execute("select * from brand")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'bcode' : row[0],'bname': row[1],'sid':row[2]}
		list.append(w)
	return  render(request ,'brand.html',{'list':list,'sid':request.session['uid']})
def addbrand(request):
	cursor=connection.cursor()
	bid=request.GET['txtbid']
	bname=request.GET['txtname']
	sql2="select * from brand where bcode='%s' and bname='%s' " %(bid,bname)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('ALREADY EXIST!');window.location='/brand/';</script>"
	else:
		sql="insert into brand(bcode,bname,sid) values('%s','%s','%s')"%(bid,bname,request.session['uid'])
		cursor.execute(sql)
		html="<script>alert('successfully addes!');window.location='/brand/';</script>"
	return HttpResponse(html)
def deletebrand(request):
	cursor=connection.cursor()
	bid=request.GET['id']
	sql="delete from  brand where bcode='%s' " %(bid)
	cursor.execute(sql)
	html="<script>alert('successfully deleted!');window.location='/brand/';</script>"
	return HttpResponse(html)
def deletecart(request):
	cursor=connection.cursor()
	id=request.GET['id']
	sql="delete from  cart where cartid='%s'"  %(id)
	cursor.execute(sql)
	html="<script>alert('successfully deleted!');window.location='/viewcart/';</script>"
	return HttpResponse(html)
def cat(request):
	cursor = connection.cursor()
	cursor.execute("select * from cat")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'catcode' : row[0],'catname': row[1]}
		list.append(w)
	return  render(request ,'set.html',{'list':list,'sid':request.session['uid']})
def addcat(request):
	cursor=connection.cursor()
	bid=request.GET['t1']
	bname=request.GET['t2']
	sql2="select * from cat where catcode='%s' and catname='%s' " %(bid,bname)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('ALREADY EXIST!');window.location='/cat/';</script>"
	else:
		sql="insert into cat(catcode,catname) values('%s','%s')"%(bid,bname)
		cursor.execute(sql)
		html="<script>alert('successfully added!');window.location='/cat/';</script>"
	return HttpResponse(html)
def deletecat(request):
	cursor=connection.cursor()
	bid=request.GET['id']
	sql="delete from  cat where catcode='%s' " %(bid)
	cursor.execute(sql)
	html="<script>alert('successfully deleted!');window.location='/cat/';</script>"
	return HttpResponse(html)
def vcat(request):
	cursor = connection.cursor()
	cursor.execute("select * from cat")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'catcode' : row[0],'catname': row[1]}
		list.append(w)
	return  render(request ,'vcat.html',{'list':list,'sid':request.session['uid']})
def sell(request):
	cursor = connection.cursor()
	cursor.execute("select * from brand")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'bcode' : row[0],'bname': row[1],'sid':row[2]}
		list.append(w)
	cursor.execute("select * from cat")
	result = cursor.fetchall()
	cat=[]
	for row in result:
		w = {'catcode' : row[0],'catname': row[1]}
		cat.append(w)
	return  render(request ,'sell.html',{'list':list,'cat':cat})
def productadd(request):
	if request.method == "POST":
			MyProfileForm = productform(request.POST, request.FILES)
			if MyProfileForm.is_valid():
				profile =pmodel()
				profile.pcode =MyProfileForm.cleaned_data["pcode"]
				profile.pname = MyProfileForm.cleaned_data["pname"]
				profile.descp =request.POST["t3"]
				profile.catcode = request.POST["t4"]
				profile.brand = request.POST["t6"]
				profile.qty = request.POST["t7"]
				profile.amt = request.POST["t8"]
				profile.vid = request.session["uid"]
				profile.img = MyProfileForm.cleaned_data["img"]
				profile.count =6
				profile.save()
				html = "<script>alert('successfully added! ');window.location='/stock/';</script>"
				saved = True
	else:
		MyProfileForm = productform()
	return HttpResponse(html)
def stock(request):
	cursor = connection.cursor()
	cursor.execute("select * from product ") 
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8],'count':row[9]}
		list.append(w)
	return  render(request ,'stock.html',{'list':list})
def updateproduct(request):
	pcode=request.GET['id']
	cursor = connection.cursor()
	cursor.execute(("select * from product where pcode='%s'") %(pcode))
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8]}
		list.append(w)
	return  render(request ,'uppro.html',{'list':list})
def editstock(request):
	cursor=connection.cursor()
	pcode=request.GET['t1']
	descp=request.GET['t3']
	qty=request.GET['t7']
	amt=request.GET['t8']
	sql="update product set descp='%s',qty='%s',amt='%s' where pcode='%s'"%(descp,qty,amt,pcode)
	cursor.execute(sql)
	html="<script>alert('successfully updated!');window.location='/stock/';</script>"
	return HttpResponse(html)
def deleteproduct(request):
	cursor=connection.cursor()
	pcode=request.GET['id']
	sql="delete from product where pcode='%s'"%(pcode)
	cursor.execute(sql)
	sql2="delete from orders where pcode='%s'"%(pcode)
	cursor.execute(sql2)
	html="<script>alert('successfully deleted!');window.location='/stock/';</script>"
	return HttpResponse(html)
# ----------------------------------------
def userregistration(request):
	return  render(request ,'userreg.html')
def regaction(request):
	cursor=connection.cursor()
	name=request.GET['t1']
	address=request.GET['t2']
	gender=request.GET['g']
	mobile=request.GET['t3']
	password=request.GET['t6']
	email=request.GET['t4']
	sql2="select * from login where uname='%s'" %(email)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('already registerd');window.location='/user_reg/';</script>"
	else:
		sql="insert into customer(cname,addr,ph,email,gen) values('%s','%s','%s','%s','%s')"%(name,address,mobile,email,gender)
		cursor.execute(sql)
		sql3="select max(cid) as cid from customer" 
		cursor.execute(sql3)
		result=cursor.fetchall()
		for row in result:
			id=int(row[0])
		sql="insert into login(uid,uname,upass,utype) values('%s','%s','%s','%s')"%(id,email,password,'cust')
		cursor.execute(sql)
		html="<script>alert('successfully registered!');window.location='/login/';</script>"
	return HttpResponse(html)
def shopregaction(request):
	cursor=connection.cursor()
	name=request.GET['t1']
	address=request.GET['t2']
	mobile=request.GET['t3']
	email=request.GET['t4']
	lno=request.GET['t5']
	password=request.GET['t6']
	sql2="select * from login where uname='%s'" %(email)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('already registerd');window.location='/user_reg/';</script>"
	else:
		sql="insert into shop(sname,addr,ph,email,lno) values('%s','%s','%s','%s','%s')"%(name,address,mobile,email,lno)
		cursor.execute(sql)
		sql3="select max(sid) as sid from shop" 
		cursor.execute(sql3)
		result=cursor.fetchall()
		for row in result:
			id=int(row[0])
		sql="insert into login(uid,uname,upass,utype) values('%s','%s','%s','%s')"%(id,email,password,'shop')
		cursor.execute(sql)
		html="<script>alert('successfully registered!');window.location='/login/';</script>"
	return HttpResponse(html)	
def dregaction(request):
	cursor=connection.cursor()
	name=request.GET['t1']
	address=request.GET['t2']
	mobile=request.GET['t3']
	email=request.GET['t4']
	dlno=request.GET['t5']
	gender=request.GET['g']
	password=request.GET['t6']
	sql2="select * from login where uname='%s'" %(email)
	cursor.execute(sql2)
	result=cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('already registerd');window.location='/user_reg/';</script>"
	else:
		sql="insert into delboy(dname,addr,ph,email,dlno,gen) values('%s','%s','%s','%s','%s','%s')"%(name,address,mobile,email,dlno,gender)
		cursor.execute(sql)
		sql3="select max(did) as cid from delboy" 
		cursor.execute(sql3)
		result=cursor.fetchall()
		for row in result:
			id=int(row[0])
		sql="insert into login(uid,uname,upass,utype) values('%s','%s','%s','%s')"%(id,email,password,'dboy')
		cursor.execute(sql)
		html="<script>alert('successfully registered!');window.location='/login/';</script>"
	return HttpResponse(html)
def buyerhome(request):
	#p=request.GET['tt']
	cursor = connection.cursor()
	query1="select * from product  where count>5 ORDER BY id DESC LIMIT 6"
	cursor.execute(query1)
	result2 = cursor.fetchall()
	list=[]
	for row in result2:
		w1 = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8]}
		list.append(w1)	
	return  render(request ,'buyerhome1.html',{'list':list})
def productcust(request):
	#p=request.GET['tt']
	cursor = connection.cursor()
	query1="select * from product where count>5 "
	cursor.execute(query1)
	result2 = cursor.fetchall()
	list=[]
	for row in result2:
		w1 = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8]}
		list.append(w1)	
	return  render(request ,'buyerhome1.html',{'list':list})
def dproduct(request):
	#p=request.GET['tt']
	cursor = connection.cursor()
	query1="select * from product inner join brand  on brand.bcode=product.brand inner join cat  on cat.catcode=product.catcode where product.pcode='%s'" %(request.GET['pcode'])
	cursor.execute(query1)
	result2 = cursor.fetchall()
	list=[]
	for row in result2:
		w1 = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[12],'brand' : row[10],'qty': row[6],'amt':row[7],'img': row[8]}
		list.append(w1)	
	return  render(request ,'details.html',{'list':list})
def buyerhome1(request):
	p=request.GET['tt']
	cursor = connection.cursor()
	if(p=="low"): 
		query="select * from product ORDER BY amt ASC" ;
	elif(p=="high"):
		query="select * from product ORDER BY amt desc" ;
	else:
		query="select * from product inner join cat on product.catcode=cat.catcode  inner join brand  on brand.bcode=product.brand where product.pname  like '%s%%' or cat.catname  like '%s%%' or  brand.bname  like '%s%%' "%(p,p,p)
	cursor.execute(query)
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8]}
		list.append(w)
	return  render(request ,'buyerhome1.html',{'list':list})
def viewproduct(request):
	pcode=request.GET['id']
	cursor = connection.cursor()
	cursor.execute(("select * from product where pcode='%s'") %(pcode))
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'vid':row[8],'img': row[9]}
		list.append(w)
		brand=row[5]
		catcode=row[4]
	cursor.execute(("select * from review where pcode='%s'") %(pcode))
	result = cursor.fetchall()
	rev=[]
	for row in result:
		r = {'rid' : row[0],'pcode': row[1],'rvw':row[2]}
		rev.append(r)
	cursor.execute(("select * from suggetion where catcode='%s'  and bcode='%s' and uid='%s'") %(catcode,brand,request.session['uid']))
	result = cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		for row2 in result:
			count=row2[4]
		cnt=count+1
		cursor.execute(("update  suggetion  set count='%s' where catcode='%s'  and bcode='%s' and uid='%s'") %(cnt,catcode,brand,request.session['uid']))
	else:
		sql="insert suggetion (uid,catcode,bcode,count) values('%s','%s','%s','%d')"%(request.session['uid'],catcode,brand,1)
		cursor.execute(sql)
	return render(request ,'product.html',{'list':list,'rev':rev})
def addcart(request):
	cursor=connection.cursor()
	pid=request.GET['id']
	cursor.execute(("select * from cart  where pcode='%s' and cid='%s' ") %(pid,request.session['uid']))
	result = cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		html="<script>alert('already exist in cart  !');window.location='/viewcart/';</script>"
	else:
		sql2="insert into cart (cid,pcode,cdate) values('%s','%s','%s') " %(request.session['uid'],pid,now)
		cursor.execute(sql2)
		html="<script>alert('successfully added cart!');window.location='/viewcart/';</script>"
	return HttpResponse(html)
def rvaction(request):
	cursor=connection.cursor()
	pid=request.GET['t11']
	rv=request.GET['ta']
	
	#bname=request.GET['txtname']
	sql2="insert into review (pcode,rvw) values('%s','%s') " %(pid,rv)
	cursor.execute(sql2)
	html="<script>window.location='/viewproduct/?id=%s';</script>" %(pid)
	return HttpResponse(html)
def buyaction(request):
	cursor=connection.cursor()
	pid=request.GET['t1']
	vid=request.GET['t2']
	am=request.GET['t3']
	cid=request.session['uid']
	q=int(request.GET['qty'])
	cursor.execute("select * from orders")
	result1 = cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		cursor.execute("select max(oid) as oid from orders")
		result1 = cursor.fetchall()
		for row1 in result1:
			oid =int(row1[0])+1
	else:
		oid=1
	cursor.execute(("select * from product where pcode='%s'") %(pid))
	result = cursor.fetchall()
	list=[]
	for row in result:
		qty =int(row[6])
	nq=(qty-q)
	if (qty>=q):
		sql2="insert into orders (oid,cid,vid,pcode,qty,amt,ptype,odate,status)  values('%s','%s','%s','%s','%s','%s','%s','%s','%s') " %(oid,cid,vid,pid,q,am,'nil',now,'Pending')
		cursor.execute(sql2)
		sql3="update product set qty='%s' where pcode='%s'" %(nq,pid)
		cursor.execute(sql3)
		html="<script>window.location='/pay/';</script>" 
	else:
		html="<script>alert('Qty selected is greather than the available qty!! ');window.location='/viewproduct/?id=%s';</script>" %(pid)
	return HttpResponse(html)
def pay(request):
	return  render(request ,'pay.html')
def payaction(request):
	cursor=connection.cursor()
	pc=request.GET['p']
	cid=request.session['uid']
	cursor.execute("select max(oid) as oid from orders")
	result = cursor.fetchall()
	for row in result:
		oid =row[0]
	sql2="update orders set ptype='%s' where oid='%s'" %(pc,oid)
	cursor.execute(sql2)
	if(pc=="NB"):
		html="<script>window.location='/nb/';</script>" 
	else:
		html="<script>window.location='/buyerhome/?tt=null';</script>" 
	return HttpResponse(html)
def nb(request):
	return  render(request ,'nb.html')
def nbaction(request):
	cursor=connection.cursor()
	pc=request.GET['b']
	cursor.execute("select max(oid) as oid from orders")
	result = cursor.fetchall()
	list=[]
	for row in result:
		oid =row[0]
	sql2="update orders set bank='%s' where oid='%s'" %(pc,oid)
	cursor.execute(sql2)
	html="<script>window.location='/buyerhome/?tt=null';</script>" 
	return HttpResponse(html)
def viewcart(request):
	cid=request.session['uid']
	cursor = connection.cursor()
	cursor.execute(("select count(*) as cnt from cart where cid='%s'") %(cid))
	result = cursor.fetchall()
	for row in result:
		 count =row[0]
	cursor.execute(("select * from product inner join cart on product.pcode=cart.pcode where cart.cid='%s'") %(cid))
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'id' : row[0],'pcode': row[1],'pname':row[2],'descp':row[3],'catcode': row[4],'brand' : row[5],'qty': row[6],'amt':row[7],'img': row[8],'cartid':row[9]}
		list.append(w)
	return  render(request ,'cart.html',{'list':list,'count':count})
def buyaction1(request):
	cursor=connection.cursor()
	cursor.execute("select * from orders")
	result1 = cursor.fetchall()
	if 	(cursor.rowcount) > 0:
		cursor.execute("select max(oid) as oid from orders")
		result1 = cursor.fetchall()
		for row1 in result1:
			oid =int(row1[0])+1
	else:
		oid=1
	cid=request.session['uid']
	cursor.execute(("select * from product inner join cart on product.pcode=cart.pcode where cart.cid='%s'") %(cid))
	result = cursor.fetchall()
	for row in result:
		#t='qty'+str(row[10])
		qty=int(request.GET['qty'+str(row[9])])
		qt=int(row[6])
		cartid=row[9]
		pc=row[1]
		sc=row[7]
		nq=(qt-qty)
		if (qt>=qty):
			sql2="insert into orders (oid,cid,pcode,qty,amt,ptype,odate,status)  values('%s','%s','%s','%s','%s','%s','%s','%s') " %(oid,request.session['uid'],pc,qty,sc,'nil',now,'Pending')
			cursor.execute(sql2)
			sql3="update product set qty='%s' where pcode='%s'" %(nq,pc)
			cursor.execute(sql3)
			sql4="delete from cart where cartid='%s'" %(cartid)
			cursor.execute(sql4)
			html="<script>window.location='/pay/';</script>" 
	return HttpResponse(html)
def track(request):
	cid=request.session['uid']
	cursor = connection.cursor()
	cursor.execute("select * from orders inner join  product  on orders.pcode=product.pcode where  orders.cid='%s' and orders.status!='Cancelled'" %(cid))
	result = cursor.fetchall()
	list=[]
	#return HttpResponse(result)
	for row in result:
		tamt=int(row[3])*int(row[4])
		w = {'oid' : row[0],'cid': row[1],'pcode':row[2],'qty': row[3],'amt': row[4],'ptype': row[5],'bank':row[6],'odate':row[7],'status': row[8],'id' : row[9],'pcode': row[10],'pname':row[11],'descp':row[12],'catcode': row[13],'brand' : row[14],'qty1' : row[15],'amt1' : row[16],'img' : row[17],'tamt':tamt}
		list.append(w)
	return  render(request ,'track.html',{'list':list})
def cancelorder(request):
	cursor=connection.cursor()
	pcode=request.GET['pid']
	id=request.GET['id']
	sql="update orders set status='Cancelled' where oid='%s' and pcode='%s'"%(id,pcode)
	cursor.execute(sql)
	html="<script>alert('successfully cancel order!');window.location='/track/';</script>"
	return HttpResponse(html)
def returnorder(request):
	cursor=connection.cursor()
	pcode=request.GET['pid']
	id=request.GET['id']
	sql="update orders set status='Return' where oid='%s' and pcode='%s'"%(id,pcode)
	cursor.execute(sql)
	html="<script>alert('successfully send return request!');window.location='/track/';</script>"
	return HttpResponse(html)
def recievedreplaced(request):
	cursor=connection.cursor()
	oid=request.GET['id']
	sql="update orders set status='ReceivedReplaced' where oid='%s'"%(oid)
	cursor.execute(sql)
	html="<script>alert('successfully send return request!');window.location='/sellerhome/';</script>"
	return HttpResponse(html)
def orders(request):
	cid=request.session['uid']
	cursor = connection.cursor()
	cursor.execute("select * from orders inner join  product  on orders.pcode=product.pcode inner join customer on customer.cid=orders.cid " )
	result = cursor.fetchall()
	list=[]
	#return HttpResponse(result)
	for row in result:
		tamt=int(row[3])*int(row[4])
		w = {'oid' : row[0],'cid': row[1],'pcode':row[2],'qty': row[3],'amt': row[4],'ptype': row[5],'bank':row[6],'odate':row[7],'status': row[8],'id' : row[9],'pcode': row[10],'pname':row[11],'descp':row[12],'catcode': row[13],'brand' : row[14],'qty1' : row[15],'amt1' : row[16],'img' : row[17],'cid': row[18],'cname':row[19],'caddr':row[20],'cph': row[21],'cemail':row[22],'cgen':row[23],'tamt':tamt}
		list.append(w)
	return  render(request ,'dboyhome.html',{'list':list})
def collect(request):
	cursor=connection.cursor()
	id=request.GET['id']
	sql="update orders set status='Collected' where  oid='%s'"%(id)
	cursor.execute(sql)
	html="<script>alert('successfully collected !');window.location='/orders/';</script>"
	return HttpResponse(html)
def deliverd(request):
	cursor=connection.cursor()
	id=request.GET['id']
	sql="update orders set status='Delivered' where  oid='%s' "%(id)
	cursor.execute(sql)
	html="<script>alert('successfully delivered !');window.location='/orders/';</script>"
	return HttpResponse(html)
def ReturnCollected(request):
	cursor=connection.cursor()
	id=request.GET['id']
	sql="update orders set status='ReturnCollected' where  oid='%s' "%(id)
	cursor.execute(sql)
	html="<script>alert('successfully ReturnCollected !');window.location='/orders/';</script>"
	return HttpResponse(html)
# ------------------------------
# ----------------------------------------------College Registration--------------------------------------------------------------------------------------------------------------------	
def clgregistration(request):
	return  render(request ,'collegereg.html')
def clgregistrationinsert(request):
	cursor=connection.cursor()
	eid=request.POST["email"]
	pass1=request.POST['password']
	html = ""
	saved = False
	if request.method == "POST":
			MyProfileForm = clgform(request.POST, request.FILES)
			if MyProfileForm.is_valid():
				profile = clgmodel()
				profile.clgcategory =request.POST["clgcategory"]
				profile.clgname = MyProfileForm.cleaned_data["clgname"]
				profile.photo = MyProfileForm.cleaned_data["photo"]
				profile.address = request.POST["address"]
				profile.district = request.POST["district"]
				profile.city= request.POST["city"]
				profile.place = request.POST["place"]
				profile.contactno = request.POST["contactno"]
				profile.fblink = request.POST["fblink"]
				profile.googlemap = request.POST["googlemap"]
				profile.details = request.POST["details"]
				profile.university = request.POST["university"]
				profile.name = request.POST["name"]
				profile.email = request.POST["email"]
				profile.password= request.POST["password"]
				profile.save()
				sql3="select max(collegeid) as id from tbl_collegereg"
				cursor.execute(sql3)
				result=cursor.fetchall()
				for row in result:
					id=row[0]
				sql="insert into tbl_login(userid,username,password,usertype) values('%s','%s','%s','%s')"%(id,eid,pass1,'college')
				cursor.execute(sql)
				html = "<script>alert('successfully added! ');window.location='/clgregistration/';</script>"
				saved = True
				
	else:
		MyProfileForm = clgform()
	return HttpResponse(html)
# ----------------------------------------------add textboooks --------------------------------------------------------------------------------------------------------------------

def items(request):
	return  render(request ,'items.html')
def itemsinsert(request):
	cursor=connection.cursor()
	html = ""
	saved = False
	if request.method == "POST":
			MyProfileForm = itemform(request.POST, request.FILES)
			if MyProfileForm.is_valid():
				profile = itemmodel()
				profile.uid =request.session["uid"]
				profile.category =request.POST["cat"]
				profile.sname = MyProfileForm.cleaned_data["sname"]
				profile.tname = MyProfileForm.cleaned_data["tname"]
				profile.desp =request.POST["desp"]
				profile.price = MyProfileForm.cleaned_data["price"]
				profile.image =MyProfileForm.cleaned_data["image"]
				profile.save()
				html = "<script>alert('successfully saved! ');window.location='/textbooks/';</script>"		
	else:
		MyProfileForm = itemform()
	return HttpResponse(html)
def viewtextbook1(request):
	# template = get_template('detailes.html')
	cursor = connection.cursor()
	cursor.execute("select * from tbl_textbooks")
	result = cursor.fetchall()
	list=[]
	for row in result:
		w = {'textid' : row[0],'name': row[1],'author':row[2],'publisher':row[3],'image': row[4],'price': row[5]}
		list.append(w)
	return (list)
	#return render(request,'viewtextbook.html', {'list': list})	
def deleteac_shop(request):
	cursor=connection.cursor()
	sql="delete from  shop where sid='%s' " %(request.session["uid"])
	cursor.execute(sql)
	sq2="delete from  login where  uid='%s' and utype='shop' " %(request.session["uid"])
	cursor.execute(sq2)
	sq3="delete from  product where  vid='%s'  " %(request.session["uid"])
	cursor.execute(sq3)
	html="<script>alert('your account is  deleted!');window.location='/login/';</script>"
	return HttpResponse(html)
def deleteac_dboy(request):
	cursor=connection.cursor()
	sql="delete from  delboy where  did='%s' " %(request.session["uid"])
	cursor.execute(sql)
	sq2="delete from  login where  uid='%s' and utype='dboy' " %(request.session["uid"])
	cursor.execute(sq2)
	html="<script>alert('your account is  deleted!');window.location='/login/';</script>"
	return HttpResponse(html)
def deleteac_user(request):
	cursor=connection.cursor()
	sql="delete from  customer where  cid='%s' " %(request.session["uid"])
	cursor.execute(sql)
	sq2="delete from  login where  uid='%s' and utype='cust' " %(request.session["uid"])
	cursor.execute(sq2)
	sq3="delete from  orders where  cid='%s'  " %(request.session["uid"])
	cursor.execute(sq3)
	html="<script>alert('your account is  deleted!');window.location='/login/';</script>"
	return HttpResponse(html)
def like(request):
	#p=request.GET['tt']
	cursor = connection.cursor()
	query1="select count from product where pcode='%s' "%(request.GET['id'])
	cursor.execute(query1)
	result2 = cursor.fetchall()
	list=[]
	for row in result2:
		count=row[0]
	s=int(count)
	d=count+1
	sql="update product set count='%s'   where  pcode='%s' " %(d,request.GET["id"])
	cursor.execute(sql)
	html="<script>window.location='/buyerhome/';</script>"
	return HttpResponse(html)
def dlike(request):
	#p=request.GET['tt']
	cursor = connection.cursor()
	query1="select count from product where pcode='%s' "%(request.GET['id'])
	cursor.execute(query1)
	result2 = cursor.fetchall()
	list=[]
	for row in result2:
		count=row[0]
	s=int(count)
	d=count-1
	sql="update product set count='%s'   where  pcode='%s' " %(d,request.GET["id"])
	cursor.execute(sql)
	html="<script>window.location='/buyerhome/';</script>"
	return HttpResponse(html)