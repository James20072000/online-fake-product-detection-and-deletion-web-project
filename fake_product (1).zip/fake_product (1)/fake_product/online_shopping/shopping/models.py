from __future__ import unicode_literals
from django.db import models
# ----------------------------------------------user registration--------------------------------------------------------------------------------------------------------------------	
class pmodel(models.Model):
	pcode = models.CharField(max_length=20)
	pname = models.CharField(max_length=20)
	descp = models.CharField(max_length=20)
	catcode = models.CharField(max_length=20)
	brand = models.CharField(max_length=20)
	qty= models.CharField(max_length=20)
	amt = models.CharField(max_length=20)
	count = models.CharField(max_length=20)
	img= models.FileField(upload_to='pictures')
	class Meta:
		db_table = "product"
