from django import forms
from django.forms import CharField
from shopping.models import pmodel

CHOICES=[('select1','select 1'),
         ('select2','select 2')]
# ----------------------------------------------user registration-------------------------------------------------------------------------------------------------------------------			 
class productform(forms.Form):
	#title = forms.CharField(max_length=20)
	pcode = forms.CharField(max_length=20)
	pname = forms.CharField(max_length=20)
	img = forms.FileField()
	class Meta:
		model = pmodel
		fields = ['pcode','pname','descp','catcode','brand','qty','amt','img','count']
		
# ----------------------------------------------clg registration---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------					
