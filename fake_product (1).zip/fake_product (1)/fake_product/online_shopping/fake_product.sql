/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50130
Source Host           : localhost:3306
Source Database       : fake_product

Target Server Type    : MYSQL
Target Server Version : 50130
File Encoding         : 65001

Date: 2021-01-14 09:28:28
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `auth_group`
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for `auth_group_permissions`
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissions_group_id_58c48ba9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for `auth_permission`
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_51277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES ('1', 'Can add log entry', '1', 'add_logentry');
INSERT INTO `auth_permission` VALUES ('2', 'Can change log entry', '1', 'change_logentry');
INSERT INTO `auth_permission` VALUES ('3', 'Can delete log entry', '1', 'delete_logentry');
INSERT INTO `auth_permission` VALUES ('4', 'Can add permission', '2', 'add_permission');
INSERT INTO `auth_permission` VALUES ('5', 'Can change permission', '2', 'change_permission');
INSERT INTO `auth_permission` VALUES ('6', 'Can delete permission', '2', 'delete_permission');
INSERT INTO `auth_permission` VALUES ('7', 'Can add group', '3', 'add_group');
INSERT INTO `auth_permission` VALUES ('8', 'Can change group', '3', 'change_group');
INSERT INTO `auth_permission` VALUES ('9', 'Can delete group', '3', 'delete_group');
INSERT INTO `auth_permission` VALUES ('10', 'Can add user', '4', 'add_user');
INSERT INTO `auth_permission` VALUES ('11', 'Can change user', '4', 'change_user');
INSERT INTO `auth_permission` VALUES ('12', 'Can delete user', '4', 'delete_user');
INSERT INTO `auth_permission` VALUES ('13', 'Can add content type', '5', 'add_contenttype');
INSERT INTO `auth_permission` VALUES ('14', 'Can change content type', '5', 'change_contenttype');
INSERT INTO `auth_permission` VALUES ('15', 'Can delete content type', '5', 'delete_contenttype');
INSERT INTO `auth_permission` VALUES ('16', 'Can add session', '6', 'add_session');
INSERT INTO `auth_permission` VALUES ('17', 'Can change session', '6', 'change_session');
INSERT INTO `auth_permission` VALUES ('18', 'Can delete session', '6', 'delete_session');

-- ----------------------------
-- Table structure for `auth_user`
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_user
-- ----------------------------

-- ----------------------------
-- Table structure for `auth_user_groups`
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_30a071c9_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_30a071c9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_24702650_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for `auth_user_user_permissions`
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_user_permissions_user_id_7cd7acb6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for `brand`
-- ----------------------------
DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `bcode` varchar(20) NOT NULL,
  `bname` varchar(20) NOT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`bcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of brand
-- ----------------------------
INSERT INTO `brand` VALUES ('smoo1', 'samsung', '0');

-- ----------------------------
-- Table structure for `cart`
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cartid` int(20) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(20) NOT NULL,
  `cid` int(20) NOT NULL,
  `cdate` varchar(25) NOT NULL,
  PRIMARY KEY (`cartid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cart
-- ----------------------------

-- ----------------------------
-- Table structure for `cat`
-- ----------------------------
DROP TABLE IF EXISTS `cat`;
CREATE TABLE `cat` (
  `catcode` varchar(20) NOT NULL,
  `catname` varchar(20) NOT NULL,
  PRIMARY KEY (`catcode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of cat
-- ----------------------------
INSERT INTO `cat` VALUES ('stgoo1', 'storage device');

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `gen` varchar(15) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('1', 'sdfa', 'hgfhgf', '9876543210', 'asd@asd.sadf', 'M');
INSERT INTO `customer` VALUES ('2', 'anuc sithara', 'k\r\no\r\nlp', '7418529631', 'anu@gmail.com', 'F');
INSERT INTO `customer` VALUES ('3', 'ann seenu', 'poiuytr\r\njuiop\r\npin 890123', '7894656123', 'ann@gmail.co9m', 'F');
INSERT INTO `customer` VALUES ('4', 'reni', 'thopiil', '9045667711', 'reni@gmail.com', 'F');
INSERT INTO `customer` VALUES ('5', 'sneha', 'bhyu', '9966332255', 'sneha@gmail.com', 'F');

-- ----------------------------
-- Table structure for `delboy`
-- ----------------------------
DROP TABLE IF EXISTS `delboy`;
CREATE TABLE `delboy` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `dname` varchar(20) NOT NULL,
  `addr` varchar(20) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `dlno` varchar(20) NOT NULL,
  `gen` varchar(15) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of delboy
-- ----------------------------
INSERT INTO `delboy` VALUES ('1', 'kiran', 'nijuhg', '7894561231', 'kiran@gmail.com', '12132', 'M');
INSERT INTO `delboy` VALUES ('2', 'joel', 'thoppil', '9090909090', 'joel@gmail.com', '9090', 'F');

-- ----------------------------
-- Table structure for `django_admin_log`
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_5151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_1c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_user_id_1c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin__content_type_id_5151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for `django_content_type`
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_3ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES ('1', 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES ('3', 'auth', 'group');
INSERT INTO `django_content_type` VALUES ('2', 'auth', 'permission');
INSERT INTO `django_content_type` VALUES ('4', 'auth', 'user');
INSERT INTO `django_content_type` VALUES ('5', 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES ('6', 'sessions', 'session');

-- ----------------------------
-- Table structure for `django_migrations`
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES ('1', 'contenttypes', '0001_initial', '2019-04-29 07:00:03');
INSERT INTO `django_migrations` VALUES ('2', 'auth', '0001_initial', '2019-04-29 07:00:10');
INSERT INTO `django_migrations` VALUES ('3', 'admin', '0001_initial', '2019-04-29 07:00:11');
INSERT INTO `django_migrations` VALUES ('4', 'contenttypes', '0002_remove_content_type_name', '2019-04-29 07:00:12');
INSERT INTO `django_migrations` VALUES ('5', 'auth', '0002_alter_permission_name_max_length', '2019-04-29 07:00:12');
INSERT INTO `django_migrations` VALUES ('6', 'auth', '0003_alter_user_email_max_length', '2019-04-29 07:00:13');
INSERT INTO `django_migrations` VALUES ('7', 'auth', '0004_alter_user_username_opts', '2019-04-29 07:00:13');
INSERT INTO `django_migrations` VALUES ('8', 'auth', '0005_alter_user_last_login_null', '2019-04-29 07:00:13');
INSERT INTO `django_migrations` VALUES ('9', 'auth', '0006_require_contenttypes_0002', '2019-04-29 07:00:13');
INSERT INTO `django_migrations` VALUES ('10', 'sessions', '0001_initial', '2019-04-29 07:00:14');

-- ----------------------------
-- Table structure for `django_session`
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('3m83yiteer1m6r8f93na86jcmu9qq0fn', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2020-02-25 16:46:36');
INSERT INTO `django_session` VALUES ('3py50f3tb98f2k2cpyzxcuy8fi48f06c', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2020-03-12 19:10:35');
INSERT INTO `django_session` VALUES ('63e98u23g2ls2p2j9rm99z8txiq8afrx', 'NDQ4N2FmOTEwZDljMjc4Yjg4YjI3NmIxNWJiOTdjMjc3NWE3NjcwYjp7InVzZXJuYW1lIjoic3JlZUBnbWFpbC5jb20iLCJ1dHlwZSI6InNob3AiLCJ1aWQiOjJ9', '2020-03-12 18:03:08');
INSERT INTO `django_session` VALUES ('70ayag497297qvrlvyary0gudbb5e8ol', 'NzIzMjcyYTllZDg1NzM4ZmE0NjQ2ODBlNzAyZTRkZmViMTA1ZWFlNzp7InVzZXJuYW1lIjoiYXJ1bkBnbWFpbC5jb20iLCJ1dHlwZSI6ImRib3kiLCJ1aWQiOjN9', '2019-05-16 09:38:58');
INSERT INTO `django_session` VALUES ('85pfwxkkmcnaa9f83qyycyukju14bty2', 'ZTJjYjVjYTAwMjg4MGE4MzUyZjg3OGU5MDA3ODE2Nzk4YzdkYTc0ZDp7InVzZXJuYW1lIjoiYWRtaW4ifQ==', '2020-03-13 08:20:14');
INSERT INTO `django_session` VALUES ('88ixi60ecop7tz2e04pcbwdxy9nrj0ts', 'ZjMwYTk1NWM1ZmZhZjg0ZDYwM2Q2NGM0Njg5Zjc0M2JmYmZmZGZiMjp7InVzZXJuYW1lIjoicXciLCJ1dHlwZSI6ImN1c3QiLCJ1aWQiOjF9', '2019-05-15 07:32:04');
INSERT INTO `django_session` VALUES ('apv3avdc5osunh0hz48vzw2jsjssgtt3', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2019-06-03 10:12:24');
INSERT INTO `django_session` VALUES ('fc5edr610lye754nywkodfkaqrtn2ad3', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2020-03-12 17:37:05');
INSERT INTO `django_session` VALUES ('i6kc2t5nf0ycz5tt5ksdr42wi0qaorti', 'MjhkNjdhYmRkNDZhYTY5YjllY2FiNGI3YWZlMDY1MzNiNGU2ZTEwNzp7InVzZXJuYW1lIjoiYW51QGdtYWlsLmNvbSIsInV0eXBlIjoiY3VzdCIsInVpZCI6Mn0=', '2020-02-14 15:36:33');
INSERT INTO `django_session` VALUES ('lsk9bkg5nindvt0fsyrqcxr3no3kxdjv', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2021-01-28 03:54:52');
INSERT INTO `django_session` VALUES ('maq4gfc7viqenzdoc23g6edr1mp18kmh', 'MDk2ZGY1MjJhMDI0YjNlMTgwNjdiNDM0MGZkY2UxMmZkNTM5NjZkMzp7InVzZXJuYW1lIjoia2lyYW5AZ21haWwuY29tIiwidXR5cGUiOiJkYm95IiwidWlkIjoxfQ==', '2019-06-24 05:01:11');
INSERT INTO `django_session` VALUES ('quxateq4uy44m5srk79w2qzpqt2asqj2', 'N2JjMTE1NzVhMzhiODRkNWYyM2U1OTY4NWVmMzQ3ZTc3ZTlkMmNhYTp7InVzZXJuYW1lIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIiwidWlkIjowfQ==', '2019-06-11 05:20:49');
INSERT INTO `django_session` VALUES ('yhudhlmuuog4cwcs4bk0d6ow1pmlh71f', 'NjhlOTZlMjIwMTRhYjU2MzRkNTlmYTIwNDAzN2M5ZmVjMWZlZjQ4OTp7InVzZXJuYW1lIjoiaEBnbWFpbC5jbyIsInV0eXBlIjoiY3VzdCIsInVpZCI6NH0=', '2019-06-11 11:52:05');

-- ----------------------------
-- Table structure for `login`
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `uid` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `upass` varchar(20) NOT NULL,
  `utype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('0', 'admin', 'admin', 'admin');
INSERT INTO `login` VALUES ('1', 'qw', 'qw', 'cust');
INSERT INTO `login` VALUES ('2', 'anu@gmail.com', 'anu', 'cust');
INSERT INTO `login` VALUES ('3', 'ann@gmail.com', '123', 'cust');
INSERT INTO `login` VALUES ('4', 'reni@gmail.com', 'reni', 'cust');
INSERT INTO `login` VALUES ('5', 'sneha@gmail.com', 'sneha', 'cust');

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `cid` varchar(20) NOT NULL,
  `pcode` varchar(20) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `amt` varchar(20) NOT NULL,
  `ptype` varchar(30) NOT NULL,
  `bank` varchar(30) DEFAULT NULL,
  `odate` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('2', '3', 'poo13', '1', '30000', 'COD', null, '2020-02-28', 'Cancelled');
INSERT INTO `orders` VALUES ('2', '3', 'poo12', '1', '1200', 'COD', null, '2020-02-28', 'Delivered');

-- ----------------------------
-- Table structure for `orders_copy`
-- ----------------------------
DROP TABLE IF EXISTS `orders_copy`;
CREATE TABLE `orders_copy` (
  `oid` int(11) NOT NULL,
  `cid` varchar(20) NOT NULL,
  `vid` varchar(20) NOT NULL,
  `pcode` varchar(20) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `amt` varchar(20) NOT NULL,
  `ptype` varchar(30) NOT NULL,
  `bank` varchar(30) DEFAULT NULL,
  `odate` varchar(30) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `did` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of orders_copy
-- ----------------------------
INSERT INTO `orders_copy` VALUES ('1', '1', '1', 'poo2', '2', '1500', 'NB', 'cb', '2019-05-02', 'Pending', null);

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(20) NOT NULL,
  `pname` varchar(25) NOT NULL,
  `descp` varchar(500) NOT NULL,
  `catcode` varchar(25) NOT NULL,
  `brand` varchar(25) NOT NULL,
  `qty` varchar(20) NOT NULL,
  `amt` int(20) NOT NULL,
  `img` varchar(500) NOT NULL,
  `count` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES ('12', 'poo13', 'sisplay', 'ertyuu', 'stgoo1', 'smoo1', '117', '30000', 'pictures/big_pic.jpg', '10');
INSERT INTO `product` VALUES ('13', 'poo12', 'pendrive', 'cpr', 'stgoo1', 'smoo1', '4', '1200', 'pictures/camera_lcvsHcg.png', '10');
INSERT INTO `product` VALUES ('14', '123', 'storage device', 'ernakulam', 'stgoo1', 'smoo1', '123', '1200', 'pictures/iphone_VfjMDnm.png', '10');
INSERT INTO `product` VALUES ('15', 'mool', 'mouse123', 'maths', 'stgoo1', 'smoo1', '12', '123', 'pictures/images_2.jpg', '10');
INSERT INTO `product` VALUES ('16', 'uuu', 'fdf', 'dsf', 'stgoo1', 'smoo1', '12', '40000', 'pictures/Jellyfish.jpg', '6');

-- ----------------------------
-- Table structure for `review`
-- ----------------------------
DROP TABLE IF EXISTS `review`;
CREATE TABLE `review` (
  `rvid` int(10) NOT NULL AUTO_INCREMENT,
  `pcode` varchar(50) DEFAULT NULL,
  `rvw` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`rvid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of review
-- ----------------------------
INSERT INTO `review` VALUES ('1', 'poo2', 'very good');
INSERT INTO `review` VALUES ('2', 'poo2', 'nice one');
INSERT INTO `review` VALUES ('3', 's001', 'uiop[');
INSERT INTO `review` VALUES ('4', '8', 'hai');
INSERT INTO `review` VALUES ('5', 'p7', 'good');

-- ----------------------------
-- Table structure for `shop`
-- ----------------------------
DROP TABLE IF EXISTS `shop`;
CREATE TABLE `shop` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) NOT NULL,
  `addr` varchar(20) NOT NULL,
  `ph` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `lno` varchar(50) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of shop
-- ----------------------------
INSERT INTO `shop` VALUES ('2', 'gyu', 'wergt', '4561237897', 'v@gmail.com', 'fdscdsf');
INSERT INTO `shop` VALUES ('3', 'jk', 'jk', '8989898989', 'jk@gmail.com', '1213');
INSERT INTO `shop` VALUES ('4', 'jkk', 'jkk', '7878787878', 'jkk@gmail.com', '123');

-- ----------------------------
-- Table structure for `suggetion`
-- ----------------------------
DROP TABLE IF EXISTS `suggetion`;
CREATE TABLE `suggetion` (
  `suggionid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(10) DEFAULT NULL,
  `catcode` varchar(10) DEFAULT NULL,
  `bcode` varchar(10) DEFAULT NULL,
  `count` int(10) DEFAULT NULL,
  PRIMARY KEY (`suggionid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of suggetion
-- ----------------------------
INSERT INTO `suggetion` VALUES ('3', '2', 'e001', 'sony001', '6');
INSERT INTO `suggetion` VALUES ('4', '2', 'e001', 'boat001', '12');
INSERT INTO `suggetion` VALUES ('5', '2', 'bag001', 'boat001', '5');
INSERT INTO `suggetion` VALUES ('6', '2', 'bag001', 'puma001', '4');
INSERT INTO `suggetion` VALUES ('7', '4', 'bag001', 'boat001', '3');
INSERT INTO `suggetion` VALUES ('8', '3', 'bag001', 'boat001', '5');
INSERT INTO `suggetion` VALUES ('9', '3', 'bag001', 'puma001', '2');
INSERT INTO `suggetion` VALUES ('10', '4', 'laptop1', 'tcs11', '13');
INSERT INTO `suggetion` VALUES ('11', '4', 'laptop11', 'boat001', '1');
INSERT INTO `suggetion` VALUES ('12', '3', 'laptop11', 'tcs11', '2');
INSERT INTO `suggetion` VALUES ('13', '3', 'stgoo1', 'smoo1', '1');
